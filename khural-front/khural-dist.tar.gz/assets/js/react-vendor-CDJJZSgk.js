import{a as o}from"./antd-vendor-C7uGMcVz.js";var a,r=o;a=r.createRoot,r.hydrateRoot;export{a as c};
