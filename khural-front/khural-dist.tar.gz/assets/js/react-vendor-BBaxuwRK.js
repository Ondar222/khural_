import{a as o}from"./antd-vendor-ByUz4t4i.js";var a,r=o;a=r.createRoot,r.hydrateRoot;export{a as c};
